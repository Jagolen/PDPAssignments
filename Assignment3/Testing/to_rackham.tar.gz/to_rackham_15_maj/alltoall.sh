#!/bin/bash -l

#SBATCH -M snowy
#SBATCH -A uppmax2022-2-11
#SBATCH -p core -n 16
#SBATCH -t 3:00

module load gcc openmpi
mpirun -np 16 ./matmul /proj/uppmax2022-2-11/nobackup/matmul_indata/input9072.txt output.txt
